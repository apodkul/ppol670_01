### Lab 06

# Aiming to create a choropleth map of German 
# election results of the party list vote by state 
library(dplyr)

## Step 0: Collect Election Results 
library(rvest)
url <- 'https://en.wikipedia.org/wiki/Results_of_the_2021_German_federal_election'

web_data <- read_html(url)

elec_results <- web_data %>% 
  html_table()

elec_results

elec_results <- elec_results[[12]]

## Step 0.5: Data Cleaning 
elec_results %>%
  View()

### Adjust variable names
names(elec_results)

names(elec_results) <- elec_results[1,]

### Remove Non Data Rows 
elec_results <- elec_results %>% 
  slice(3:18)

### Convert data type to numeric 
elec_results$SPD <- as.numeric(elec_results$SPD)


## Step 1: Load Shape file
#install.packages("rgdal")
de_shp <- rgdal::readOGR(dsn = 'Germany_shapefile', 
                         layer = 'de_admin1')

de_shp %>% 
  glimpse()


## Step 2: Fortify Data Set 
de_shp_f <- ggplot2::fortify(de_shp, region = 'NAME_1')

de_shp_f %>% 
  glimpse()

## Step 2.5: Check the map
library(ggplot2)

ggplot(de_shp_f) + 
  geom_polygon(aes(x = long, y = lat, 
                   group = group))

## Step 3: Join Data Sets
table(de_shp_f$id)
table(elec_results$State)

elec_results <- elec_results %>% 
  mutate(id = case_when(
    State == 'Bavaria' ~ 'Bayern',
    State == 'Hesse' ~ 'Hessen',
    State == 'Lower Saxony' ~ 'Niedersachsen', 
    State == 'North Rhine-Westphalia' ~ 'Nordrhein-Westfalen',
    State == 'Rhineland-Palatinate' ~ 'Rheinland-Pfalz',
    State == 'Saxony' ~ 'Sachsen', 
    State == 'Saxony-Anhalt' ~ 'Sachsen-Anhalt',
    State == 'Thuringia' ~ 'Thüringen',
    TRUE ~ State
  ))

de_shp_f <- de_shp_f %>% 
  left_join(elec_results, by = 'id')

de_shp_f %>% 
  glimpse()

## Step 4: Plot 
ggplot(de_shp_f) + 
  geom_polygon(aes(x = long, y = lat, 
                   group = group, 
                   fill = SPD), 
               color = 'gray')



## Step 5: Adjust 
ggplot(de_shp_f) + 
  geom_polygon(aes(x = long, y = lat, 
                   group = group, 
                   fill = SPD), 
               color = 'gray') + 
  coord_map() + 
  scale_fill_gradient(low = 'white', 
                      high = '#EB001F') + 
  theme_void() + 
  theme(legend.position = 'bottom')

# Work with Leaflet 
#install.packages("leaflet")
library(leaflet)

leaflet() 

leaflet() %>% 
  addTiles()

leaflet() %>% 
  addTiles() 

leaflet() %>% 
  addTiles() %>% 
  addMarkers(lng = 13.4050, 
             lat = 52.52,
             popup = 'Berlin')

leaflet() %>% 
  addTiles() %>% 
  addPolygons()


leaflet(de_shp) %>% 
  addTiles() %>%
  addPolygons(label = de_shp$NAME_1, 
              fillColor = '#041E42', 
              fillOpacity = .8, 
              color = '#63666A')

#install.packages("tigris")
de_shp_2 <- tigris::geo_join(de_shp, elec_results,
                         'NAME_1', 'id')
names(de_shp_2)


pal <- colorNumeric('Reds', 
                   domain = de_shp_2$SPD
                   )


leaflet(de_shp_2) %>% 
  addTiles() %>%
  addPolygons(label = de_shp_2$NAME_1, 
              fillColor = ~pal(de_shp_2$SPD),
              #fillColor = '#041E42', 
              fillOpacity = .8, 
              color = '#63666A')



# Distance
#install.packages('rgeos')
rgeos::gCentroid(de_shp_2)

rgeos::gCentroid(de_shp_2, byid = T)

#Geocoding 
#install.packages('tidygeocoder')
library(tidygeocoder)

to_geocode <- data.frame(id = 1:5, 
                         names = c("Berlin", 
                                   "Frankfurt", 
                                   "Dresden", 
                                   "Cologne", 
                                   "Leipzig"), 
                         country = "Germany", 
                         country_abbrev = 'DE')

new_geocode <- to_geocode %>% 
  geocode(country = country, city = names)
#read documentation -- this is an rate limited API wrapper 

ggplot(de_shp_f) + 
  geom_polygon(aes(x = long, y = lat, 
                   group = group, 
                   fill = SPD), 
               color = 'gray') + 
  coord_map() + 
  scale_fill_gradient(low = 'white', 
                      high = '#EB001F') + 
  theme_void() + 
  theme(legend.position = 'bottom') + 
  geom_label(data = new_geocode, 
             mapping = aes(x = long, y = lat, 
                           label = names))


